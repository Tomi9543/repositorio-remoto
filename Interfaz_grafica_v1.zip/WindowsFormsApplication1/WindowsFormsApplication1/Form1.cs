﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        

        bool moveDown, moveUp, moveLeft, moveRight;
        int speed = 6;
        Double Radius = 50;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        
        private void MoveTimerEvent(object sender, EventArgs e)
        {
           
            if (moveLeft == true && pictureBox1.Left > 0)
            {
                if (MapObstacles(pictureBox1.Top, pictureBox1.Left - speed, pictureBox2.Left, pictureBox2.Top, pictureBox2.Width, pictureBox2.Height, pictureBox1.Width, pictureBox1.Height) == false)
                    pictureBox1.Left -= speed;
            }
            if (moveRight == true && pictureBox1.Left < 882)
            {
                if (MapObstacles(pictureBox1.Top, pictureBox1.Left + speed, pictureBox2.Left, pictureBox2.Top, pictureBox2.Width, pictureBox2.Height, pictureBox1.Width, pictureBox1.Height) == false)
                    pictureBox1.Left += speed;
            }

            if (moveUp == true && pictureBox1.Top > 0)
            {
                if (MapObstacles(pictureBox1.Top - speed, pictureBox1.Left, pictureBox2.Left, pictureBox2.Top , pictureBox2.Width, pictureBox2.Height, pictureBox1.Width, pictureBox1.Height) == false)
                    pictureBox1.Top -= speed;
            }
            if (moveDown == true && pictureBox1.Top < 503)
            {
                if (MapObstacles(pictureBox1.Top + speed, pictureBox1.Left, pictureBox2.Left, pictureBox2.Top, pictureBox2.Width, pictureBox2.Height, pictureBox1.Width, pictureBox1.Height) == false)
                    pictureBox1.Top += speed;
            }
            
            bool activation = ObjectActivation(pictureBox1.Top, pictureBox1.Left, pictureBox2.Left, pictureBox2.Top, pictureBox2.Width, pictureBox2.Height, pictureBox1.Width, pictureBox1.Height);
            if (activation == false)
                pictureBox2.BackColor = Color.Black;
            else
                pictureBox2.BackColor = Color.Blue;



        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Left)
                moveLeft = true;
            if (e.KeyCode == Keys.Right)
                moveRight = true;
            if (e.KeyCode == Keys.Up)
                moveUp = true;
            if (e.KeyCode == Keys.Down)
                moveDown = true;
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
                moveLeft = false;
            if (e.KeyCode == Keys.Right)
                moveRight = false;
            if (e.KeyCode == Keys.Up)
                moveUp = false;
            if (e.KeyCode == Keys.Down)
                moveDown = false;
        }
        private bool ObjectActivation(int PositionY, int PositionX, int ObjectXleft, int ObjectYtop, int ObjectLenght, int ObjectHeight, int PouLenght, int PouHeight)
        {
            double distanceSq;
            int XcenterPou = PositionX + PouLenght / 2;
            int YcenterPou = PositionY + PouHeight / 2;

            int XcenterObj = ObjectXleft + ObjectLenght / 2;
            int YcenterObj = ObjectYtop + ObjectHeight / 2;

            distanceSq =  Math.Pow((Convert.ToDouble(YcenterPou - YcenterObj)), 2) + Math.Pow((Convert.ToDouble(XcenterPou - XcenterObj)),2);

            Double RadiusSq = Math.Pow(Radius, 2);
            if (distanceSq <= RadiusSq)
            {
                MessageBox.Show(distanceSq.ToString());
                return true;
                 
            }
            else
                return false;
        }

        private bool MapObstacles(int PositionY, int PositionX, int ObjectXleft, int ObjectYtop , int ObjectLenght, int ObjectHeight, int PouLenght, int PouHeight)
        {
            int thickness = 15;

            int Y = 0;
            bool crash = false;
            while ((Y <= ObjectHeight)&(crash == false))
            {
                if ((Y <= thickness)||(Y >= (ObjectHeight - thickness)))
                {
                    int X = 0;
                    while (( X<=ObjectLenght) & (crash == false))
                    {
                        int i = 0;
                        while  ((i < PouHeight)&(crash == false))
                        {
                            if ((i==0)||(i==PouHeight))
                            {
                                for (int j = 0; j < PouLenght; j++)
                                {
                                    if ((PositionX + j == X + ObjectXleft)&(PositionY + i == Y + ObjectYtop))
                                        crash = true;
                                }
                            }
                            else
                            {
                              
                                if ((PositionX == X + ObjectXleft)&(PositionY + i == Y + ObjectYtop))
                                    crash = true;
                                else if ((PositionX + PouLenght == X + ObjectXleft) & (PositionY + i == Y + ObjectYtop))
                                    crash = true;

                            }
                            
                            i++;
                        }

                        X++;
                    }
                }
                else
                {
                    int X = 0;
                    while ((X <= ObjectLenght) & (crash == false))
                    {
                        if ((X <= thickness) || (X > (ObjectLenght - thickness)))
                        {
                            int i = 0;
                            while ((i < PouHeight) & (crash == false))
                            {
                                if ((i == 0) || (i == PouHeight))
                                {
                                    for (int j = 0; j < PouLenght; j++)
                                    {
                                        if ((PositionX + j == X + ObjectXleft) & (PositionY + i == Y + ObjectYtop))
                                            crash = true;
                                    }
                                }
                                else
                                {
                                    if ((PositionX == X + ObjectXleft) & (PositionY + i == Y + ObjectYtop))
                                        crash = true;
                                    else if ((PositionX + PouLenght == X + ObjectXleft) & (PositionY + i == Y + ObjectYtop))
                                        crash = true;

                                }

                                i++;
                            }

                        }
                        X++;
                    }
                }
                Y++;
            }
            return crash;
        }
    }
}
